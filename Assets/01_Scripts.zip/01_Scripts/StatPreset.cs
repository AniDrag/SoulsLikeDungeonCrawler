using System.Collections.Generic;
using UnityEngine;
namespace AniDrag.Stats
{
    [CreateAssetMenu(fileName = "StatPreset", menuName = "AniDrag/Stats/StatPreset")]
    public class StatPreset : ScriptableObject
    {
        [System.Serializable]
        public struct StatEntry
        {
            public StatsType Type;
            public float BaseValue;
        }

        public List<StatEntry> DefaultStats = new List<StatEntry>();
    }
}
