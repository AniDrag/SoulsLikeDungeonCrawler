﻿#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using System;

namespace AniDrag.Stats
{
    [CreateAssetMenu(fileName = "BuffDefinition", menuName = "AniDrag/Stats/BuffDefinition")]
    public class BuffDefinition : ScriptableObject
    {
        [Tooltip("Unique ID for this buff (used at runtime & for save data). Leave empty to auto-generate.")]
        public string Id;

        public StatsType TargetStat;
        public float FlatModifier = 0f;    // +10
        public float Multiplier = 0f;      // 0.1f == +10% (applied as (1 + Multiplier))
        public float Duration = 0f;        // seconds; 0 = permanent
        public int MaxStacks = 1;          // stacking behaviour
        public bool StackDurationOnRefresh = true; // on re-apply, refresh/augment duration?

#if UNITY_EDITOR
        private void OnValidate()
        {
            // ensure this runs only in the editor and not in builds
            UpdateItemData();
        }

        [ContextMenu("Update Item")]
        private void UpdateItemData()
        {
            // Sync the ScriptableObject's display name with the Id (optional)
            if (name != Id)
                name = Id;

            // Update the asset file name in the Project window (Editor only)
            string assetPath = AssetDatabase.GetAssetPath(this);
            if (!string.IsNullOrEmpty(assetPath))
            {
                string currentFileName = System.IO.Path.GetFileNameWithoutExtension(assetPath);
                if (currentFileName != Id)
                {
                    // AssetDatabase.RenameAsset returns an empty string on success, otherwise error text
                    string result = AssetDatabase.RenameAsset(assetPath, Id);
                    if (!string.IsNullOrEmpty(result))
                    {
                        Debug.LogWarning($"[BuffDefinition] RenameAsset failed for '{assetPath}' -> '{Id}': {result}");
                    }
                    else
                    {
                        AssetDatabase.SaveAssets();
                    }
                }
            }
        }

        // Handy manual action: generate a new GUID (ContextMenu)
        [ContextMenu("Generate New ID")]
        private void GenerateNewId()
        {
            Id = Guid.NewGuid().ToString("N");
            UpdateItemData();
            EditorUtility.SetDirty(this);
        }
#endif
    }
}