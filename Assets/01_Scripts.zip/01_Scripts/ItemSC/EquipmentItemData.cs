using UnityEngine;
namespace AniDrag.Interactibles.Equipment
{

    /// <summary>
    /// Example: equipment that provides stat modifiers while equipped.
    /// Designers can add StatModifier prototypes in the inspector.
    /// EquipmentSystem will clone mods at runtime and set their SourceID to the ItemID for removal later.
    /// </summary>
    [CreateAssetMenu(fileName = "NewEquipmentItem", menuName = "AniDrag/Interactibles/Equipment/EquipmentItem")]
    public class EquipmentItemData : ItemData
    {
        [Tooltip("Stat modifier prototypes (template). Runtime clones will have SourceID set to the ItemID.")]
        public StatModifier[] modifierPrototypes = new StatModifier[0];

        // You may also add equipment-specific fields like slot type, requirement, etc.
        public string equipSlot = "Generic";

        // Example override (not strictly necessary): create instance with extra runtime info
        public override ItemInstance CreateInstance(int quantity = 1)
        {
            var inst = base.CreateInstance(quantity);
            inst.isEquippable = true;
            return inst;
        }
    }
}
