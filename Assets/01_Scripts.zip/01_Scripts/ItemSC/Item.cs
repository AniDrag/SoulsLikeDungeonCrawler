﻿using UnityEditor;
using UnityEngine;

namespace AniDrag.Interactibles.Equipment
{
    /// <summary>
    /// Base ScriptableObject definition for all item types.
    /// Inherit from this for specialized data (weapons, consumables, materials, etc).
    /// This file contains the base and two example derived SOs:
    /// - EquipmentItemData : items that grant StatModifiers when equipped
    /// - ConsumableItemData : items that can be 'used' and consumed
    /// </summary>
    public class ItemData : ScriptableObject
    {
        [Header("Identity")]
        [Tooltip("Designer visible name")]
        public string itemName = "New Item";
        [Tooltip("High-level category")]
        public ItemType type = ItemType.Default;
        [Tooltip("Icon for UI lists")]
        public Sprite icon;
        [Tooltip("Optional world prefab / spawnable object")]
        public GameObject itemPrefab;

        [Header("Inventory")]
        [Tooltip("Unique stable id (generated in editor). Use this as runtime dictionary key.")]
        public string itemID = "";
        [Tooltip("Stackable?")]
        public bool stackable = true;
        [Tooltip("Max stack if stackable")]
        public int maxStack = 99;
        [Tooltip("Rarity used for sorting/display")]
        public int rarity = 0;
        [Tooltip("Designer sort priority (tie-breaker)")]
        public int sortPriority = 0;
        [Tooltip("Tags for filtering/searching")]
        public string[] tags = new string[0];

        /// <summary>
        /// Called when creating a runtime instance of this item.
        /// Default implementation returns a simple ItemInstance.
        /// Override in derived classes if you need additional instance data.
        /// </summary>
        public virtual ItemInstance CreateInstance(int quantity = 1)
        {
            return new ItemInstance(this, Mathf.Max(1, quantity));
        }

#if UNITY_EDITOR
        protected virtual void OnValidate()
        {
            if (string.IsNullOrEmpty(itemName) == false)
            {
                // keep asset name consistent
                if (name != itemName)
                    name = itemName;
            }

            maxStack = Mathf.Max(1, maxStack);

            if (string.IsNullOrEmpty(itemID))
                GenerateID();
        }

        [ContextMenu("Generate ItemID")]
        private void GenerateID()
        {
            itemID = System.Guid.NewGuid().ToString("N");
            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssets();
        }
#endif

        /// <summary>
        /// Optional runtime behavior for the item when the player "uses" it from the inventory UI.
        /// Base implementation does nothing and returns false (not consumed).
        /// Derived types (Consumable) should override and apply effects then return true if the item was consumed.
        /// </summary>
        /// <param name="inst">The runtime ItemInstance being used</param>
        /// <param name="owner">The inventory (owner) calling use - useful to modify inventory or player.</param>
        /// <returns>True if the item was consumed and quantity should be decremented by caller</returns>
        public virtual bool Use(ItemInstance inst, AniDrag.Player.Inventory owner)
        {
            // default: nothing happens
            Debug.Log($"Used base ItemData '{itemName}' but it has no Use behavior.");
            return false;
        }
    }
    /// <summary>
    /// Equipment item definition. This ScriptableObject is intended to be an asset definition
    /// used by designers. Runtime item instances (created/destroyed during play) should use
    /// a separate serializable data object (JSON or plain class) for saving/loading.
    /// Create this Item for every equipment/Weapon/Consumable item
    /// </summary>

    /* public class Item : MonoBehaviour
     {
         #region Variables
         [Header("======== Item Details ========")]
         [SerializeField] private string itemName = "name of item";
         [SerializeField] private ItemType type = ItemType.Default;
         [SerializeField] private Sprite icon = null;
         [SerializeField] private GameObject itemObject;


         [Header("======== Sorting / Stats ========")]
         [Tooltip("Used for quick-inventory sorting (first letter)")]
         [SerializeField] private char startLetter;
         [Tooltip("Acquisition time in seconds (or whatever unit your game uses)")]
         [SerializeField] private float acquisitionTime;
         [Tooltip("Unique identifier for the item. Generate once in the editor.")]
         [SerializeField] private string itemID = "";
         [Tooltip("Is this item stackable in the inventory?")]
         [SerializeField] private bool stackable = true;
         [Tooltip("Max stack size (if stackable)")]
         [SerializeField] private int maxStack = 1;
         [Tooltip("Gameplay attributes often used for sorting")]
         [SerializeField] private DamageData damage;
         [SerializeField] private int health = 0;
         [SerializeField] private int defense = 0;
         [Tooltip("Lower = common, higher = rarer")]
         [SerializeField] private int rarity = 0;
         [Tooltip("Designer sort weight — smaller shows earlier when equal keys")]
         [SerializeField] private int sortPriority = 0;
         [Tooltip("Arbitrary tags for filtering (e.g. \"quest\", \"fire\", \"two-handed\")")]
         [SerializeField] private string[] tags = new string[0];
         #endregion
         #region Getters
         // Public read-only accessors

         public string ItemName => itemName;
         public ItemType Type => type;
         public char StartLetter => startLetter;
         public float AcquisitionTime => acquisitionTime;
         public string ItemID => itemID;
         public Sprite Icon => icon;

         public bool Stackable => stackable;
         public int MaxStack => maxStack;

         public DamageData Damage => damage;
         public int Health => health;
         public int Defense => defense;
         public int Rarity => rarity;
         public int SortPriority => sortPriority;
         public string[] Tags => tags;
         #endregion

         public Item(ItemData itemData)
         {
             itemID = itemData.itemID;
             itemName = itemData.itemName;
             type = itemData.type;
             startLetter = itemData.startLetter;
             acquisitionTime = Time.time;
             health = itemData.health;
             damage = itemData.damage;
             defense = itemData.defense;
             rarity = itemData.rarity;
             sortPriority = itemData.sortPriority;  
             tags = itemData.tags;
             stackable = itemData.stackable;
             maxStack = itemData.maxStack;

             icon = itemData.icon;
             itemObject = itemData.itemObject;
         }

     }
    */

    public enum ItemType
    {
        Default,
        Weapon,
        Armor,
        Consumable,
        KeyItem,
        Material,
    }
}
