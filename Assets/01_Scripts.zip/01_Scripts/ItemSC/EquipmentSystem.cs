using AniDrag.Events;
using AniDrag.Interactibles.Equipment;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace AniDrag.Player
{
    /// <summary>
    /// Small equipment controller that tracks equipped items by slot name and publishes
    /// EquipEvent / UnequipEvent to the EventBus. Separates the inventory (bag) from equipped items.
    /// </summary>
    public class EquipmentSystem : MonoBehaviour
    {
        // Slot -> ItemInstance (you may prefer ItemData or ItemID)
        private readonly Dictionary<string, ItemInstance> equipped = new Dictionary<string, ItemInstance>();

        /// <summary>
        /// Equip an instance into a named slot (e.g. "RightHand", "Chest").
        /// Unequips existing item in slot first.
        /// This method also publishes events that other systems (StatManager) will listen to.
        /// </summary>
        public void Equip(string slot, ItemInstance instance)
        {
            if (instance == null) return;

            // Unequip existing
            if (equipped.TryGetValue(slot, out var old) && old != null)
            {
                Unequip(slot);
            }

            equipped[slot] = instance;

            if (instance.data is EquipmentItemData equipmentData)
            {
                // Clone prototypes and publish equip event
                var clones = CloneModifiersForSource(equipmentData.itemID, equipmentData.modifierPrototypes);
                EventBus<EquipEvent>.Publish(new EquipEvent(equipmentData.itemID, clones));
            }
        }

        public void Unequip(string slot)
        {
            if (!equipped.TryGetValue(slot, out var inst) || inst == null) return;
            equipped.Remove(slot);
            if (inst.data != null)
                EventBus<UnequipEvent>.Publish(new UnequipEvent(inst.ItemID));
        }

        private StatModifier[] CloneModifiersForSource(string sourceID, StatModifier[] prototypes)
        {
            if (prototypes == null || prototypes.Length == 0) return Array.Empty<StatModifier>();
            var outMods = new StatModifier[prototypes.Length];
            for (int i = 0; i < prototypes.Length; ++i)
            {
                var p = prototypes[i];
                outMods[i] = new StatModifier(sourceID, p.TargetStat, p.Operation, p.Value, p.Priority, p.Label);
            }
            return outMods;
        }
    }
}
