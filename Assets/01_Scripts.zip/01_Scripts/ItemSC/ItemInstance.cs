using System;
namespace AniDrag.Interactibles.Equipment
{
    /// <summary>
    /// Lightweight runtime representation of an ItemData inside the inventory.
    /// Not a MonoBehaviour. Contains reference to the authoring ItemData and quantity.
    /// InstanceID is optional (useful if you need to track unique items).
    /// </summary>
    [Serializable]
    public class ItemInstance
    {
        public string InstanceID { get; private set; }     // unique per runtime instance (GUID)
        public string ItemID => data != null ? data.itemID : "";
        public ItemData data;
        public int quantity;
        public bool isEquippable = false;

        public ItemInstance(ItemData data, int quantity = 1)
        {
            this.data = data;
            this.quantity = Math.Max(1, quantity);
            InstanceID = Guid.NewGuid().ToString("N");
            isEquippable = data is EquipmentItemData;
        }

        /// <summary>
        /// Call the data-defined Use method. Returns true if the item should be consumed/removed by the caller.
        /// </summary>
        public bool Use(AniDrag.Player.Inventory owner)
        {
            if (data == null) return false;
            return data.Use(this, owner);
        }
    }
}
