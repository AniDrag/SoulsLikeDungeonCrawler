using UnityEngine;
namespace AniDrag.Interactibles.Equipment
{

    /// <summary>
    /// Example: consumable item that heals or applies instant effects.
    /// Override Use() to define behavior.
    /// </summary>
    [CreateAssetMenu(fileName = "NewConsumable", menuName = "AniDrag/Interactibles/Equipment/ConsumableItem")]
    public class ConsumableItemData : ItemData
    {
        [Tooltip("How much HP to restore on use (example)")]
        public int healAmount = 0;

        public override bool Use(ItemInstance inst, AniDrag.Player.Inventory owner)
        {
            // Example: apply heal to a player. We broadcast an event or directly call owner/player methods.
            // If you have a PlayerStats or StatManager, you'd call into that here.
            Debug.Log($"Consume {itemName}: heal {healAmount} HP");
            // Here we could publish a custom event: EventBus<ConsumeEvent>.Publish(...)
            // Return true to indicate one quantity should be consumed.
            return true;
        }
    }
}