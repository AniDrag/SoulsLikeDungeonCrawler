using System.Collections.Generic;
using UnityEngine;


namespace AniDrag.Stats
{

    public class CharacterTemplate : MonoBehaviour
    {
        [Header("Character info")]
        [SerializeField] private string CharacterName = "name unnset";
        [SerializeField] private StatPreset defaultPreset;
        [SerializeField] private int characterLevel = 0;


        [Header("Stat paramaters")]
        private Dictionary<StatsType, StatDefinition> stats = new Dictionary<StatsType, StatDefinition>();
        private Dictionary<string, BuffInstance> activeBuffs = new Dictionary<string, BuffInstance>();

        #region Geters
        public string Name => CharacterName;
        public int CharacterLevel => characterLevel;
        public StatDefinition GetStat(StatsType type) => stats[type];
        #endregion

        /// <summary>
        /// We clear the stats and create a stat for each enum containert in stats. Since all stats are needed on all enemies, npcs and players since they ll use them.
        /// Further expanded by a Default preset of Stat preset. And Classes, Races and Jobs will all dervive from said class
        /// </summary>
        private void Awake()
        {
            stats.Clear();

            if (defaultPreset != null)
            {
                foreach (var entry in defaultPreset.DefaultStats)
                    stats[entry.Type] = new StatDefinition(entry.Type, entry.BaseValue);
            }
            else
            {
                // fallback defaults if none provided
                foreach (StatsType t in System.Enum.GetValues(typeof(StatsType)))
                    stats[t] = new StatDefinition(t, 0);
            }
        }
        /// <summary>
        /// Tick timer for buff chechup and if any buff expired
        /// </summary>
        private void Update()
        {
            TickBuffs(Time.deltaTime);
        }

        #region Buff & De-Buff Functions
        /// <summary>
        /// Tracks time and decreses the duration of time on buffs
        /// </summary>
        /// <param name="dt">Time passed</param>
        private void TickBuffs(float dt)
        {
            var expired = new List<string>();
            foreach (var kv in activeBuffs)
            {
                kv.Value.Tick(dt);
                if (kv.Value.IsExpired) expired.Add(kv.Key);
            }

            foreach (var id in expired)
                RemoveBuffById(id);
        }
        /// <summary>
        /// Applying a buff, We check if the stack allows for more or not, and other safety checks.
        /// Buff Definition is passed when Using ability, goig in to a zone or other factors.
        /// After we call to apply the modifier to said stat Definition
        /// </summary>
        /// <param name="def">The SO of a buff containing buff/de-Buff Data</param>
        public void ApplyBuff(BuffDefinition def)
        {
            if (def == null) return;

            if (activeBuffs.TryGetValue(def.Id, out var existing))
            {
                existing.RefreshOrStack();
                // update modifiers for this buff (recalc)
                ReapplyBuffModifiers(existing);
            }
            else
            {
                var inst = new BuffInstance(def);
                activeBuffs[def.Id] = inst;
                AddModifiersFromInstance(inst);
            }
        }
        /// <summary>
        /// Applying said modifiers to stat
        /// </summary>
        /// <param name="inst"></param>
        private void AddModifiersFromInstance(BuffInstance inst)
        {
            var def = inst.Definition;
            if (def.FlatModifier != 0f)
                stats[def.TargetStat].AddFlat(inst.EffectiveFlat);
            if (def.Multiplier != 0f)
                stats[def.TargetStat].AddPercent(inst.EffectiveMultiplier);

            // Optionally notify UI / other systems
        }
        /// <summary>
        /// Extending / reseting buff duration if needed
        /// </summary>
        /// <param name="inst"></param>
        private void ReapplyBuffModifiers(BuffInstance inst)
        {
            // simple approach: remove then add (safe if small lists)
            var def = inst.Definition;
            if (def.FlatModifier != 0f)
            {
                stats[def.TargetStat].RemoveFlat(def.FlatModifier * (inst.Stacks - 1)); // try to adjust stack delta
                stats[def.TargetStat].AddFlat(inst.EffectiveFlat);
            }

            if (def.Multiplier != 0f)
            {
                stats[def.TargetStat].RemovePercent(def.Multiplier * (inst.Stacks - 1));
                stats[def.TargetStat].AddPercent(inst.EffectiveMultiplier);
            }
        }
        /// <summary>
        /// Removing buff and clearing stat data of said buff.
        /// </summary>
        /// <param name="id"></param>
        private void RemoveBuffById(string id)
        {
            if (!activeBuffs.TryGetValue(id, out var inst)) return;
            var def = inst.Definition;
            if (def.FlatModifier != 0f) stats[def.TargetStat].RemoveFlat(inst.EffectiveFlat);
            if (def.Multiplier != 0f) stats[def.TargetStat].RemovePercent(inst.EffectiveMultiplier);

            activeBuffs.Remove(id);
        }
        #endregion
    }
}

/*
   
    [SerializeField] private StatDefinition Vitality;
    [SerializeField] private StatDefinition Stamina;
    [SerializeField] private StatDefinition Magic;
    [SerializeField] private StatDefinition Strenght;
    [SerializeField] private StatDefinition Dexterity;
    [SerializeField] private StatDefinition Inteligence;
    [SerializeField] private StatDefinition Luck;
    
    [Header("Basic paramaters")]
    [SerializeField] private StatDefinition maxHealth;
    [SerializeField] private StatDefinition maxStamina;
    [SerializeField] private StatDefinition maxMana;
    
    [Header("Defense paramaters")]
    [SerializeField] private StatDefinition PhysicalDefense;
    [SerializeField] private StatDefinition MagicalDefense;
    
    [Header("Damage paramaters")]
    [SerializeField] private StatDefinition PhysicalDamage;
    [SerializeField] private StatDefinition MagicalDamage;
    [SerializeField] private StatDefinition CriticalChance;
    [SerializeField] private StatDefinition CriticalDamage;
    
    [Header("Other paramaters")]
    [SerializeField] private StatDefinition LootDropChance;



        public Dictionary<string, StatModifierDefinition> positiveDurationBuffs = new Dictionary<string, StatModifierDefinition>();
        public Dictionary<string, StatModifierDefinition> negativeDurationBuffs = new Dictionary<string, StatModifierDefinition>();
        public Dictionary<string, StatModifierDefinition> constantBuffs = new Dictionary<string, StatModifierDefinition>();
 
 */
