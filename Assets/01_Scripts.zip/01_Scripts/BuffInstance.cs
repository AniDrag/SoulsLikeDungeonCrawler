using AniDrag.Stats;
using UnityEngine;

public class BuffInstance : MonoBehaviour
{
    public BuffDefinition Definition; //{ get; }
    public float TimeRemaining { get; private set; }
    public int Stacks { get; private set; }

    public bool IsExpired => Definition.Duration > 0f && TimeRemaining <= 0f;

    public BuffInstance(BuffDefinition def)
    {
        Definition = def;
        Stacks = 1;
        TimeRemaining = def.Duration;
    }

    public void Tick(float dt)
    {
        if (Definition.Duration > 0f)
            TimeRemaining -= dt;
    }

    // Attempt stack; returns true if stacked or refreshed
    public void RefreshOrStack()
    {
        if (Definition.MaxStacks > Stacks)
        {
            Stacks++;
        }

        if (Definition.StackDurationOnRefresh)
            TimeRemaining = Definition.Duration;
    }

    // compute effective flat value for this instance (per-stack)
    public float EffectiveFlat => Definition.FlatModifier * Stacks;

    // compute effective multiplier for this instance (per-stack multiplicative style)
    public float EffectiveMultiplier => Definition.Multiplier * Stacks;
}
