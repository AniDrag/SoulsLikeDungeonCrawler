using UnityEngine;

namespace AniDrag.Interactibles.Equipment
{
    public class Interactible : MonoBehaviour
    {
        [SerializeField] private float interactionRadious = 2f;


        private void OnDrawGizmos()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, interactionRadious);
        }
    }
}
