using AniDrag.Interactibles.Equipment;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace AniDrag.Player
{
    // <summary>
    /// Inventory component that stores ItemInstances keyed by their stable ItemID.
    /// Supports stackable and non-stackable items.
    /// Keeps a presentable list for UI and publishes events when inventory changes.
    /// </summary>
    public class Inventory : MonoBehaviour
    {
        /// <summary>
        /// Entry used for presenting inventory rows.
        /// If an item is non-stackable we store multiple ItemInstanceenteries with quantity 1.
        /// For stackable items we aggregate quantity into one entry.
        /// </summary>
        [System.Serializable]
        public class InventoryEntry
        {
            public ItemInstance Instance;
            public int Quantity;
            /// <summary>
            /// initializing Inventory Entery with an itemInstance
            /// </summary>
            /// <param name="inst"> Item instance</param>
            /// <param name="qty"> Item Quantity</param>
            public InventoryEntry(ItemInstance inst, int qty)
            {
                Instance = inst; 
                Quantity = qty;
            }
        }
        // Internal dictionary -> ItemID -> InventoryEntery (aggregated for stackables) OR list for non-stackables
        private readonly Dictionary<string, List<InventoryEntry>> byItemID = new Dictionary<string, List<InventoryEntry>>();

        private void Awake()
        {
            // when ido initialize it.
        }

        #region Add / Remove
        /// <summary>
        /// Adds an item (authoring ItemData) to the inventory.
        /// If stackable and there is an existing stack, it increases the quantity.
        /// Returns the ItemInstance(s) created for use (single instance for stackable, one per qty for non-stackable).
        /// </summary>
        public List<ItemInstance> AddItem(ItemData data, int qty = 1)
        {
            if (data == null || qty <= 0) return new List<ItemInstance>();
            if (!byItemID.TryGetValue(data.itemID, out var entries))
            {
                entries = new List<InventoryEntry>();
                byItemID[data.itemID] = entries;
            }

            List<ItemInstance> created = new List<ItemInstance>();

            if (data.stackable)
            {
                // Use or create a single aggregated entry.
                InventoryEntry entry = entries.FirstOrDefault();
                if (entry == null)
                {
                    var inst = data.CreateInstance(qty);
                    entry = new InventoryEntry(inst, qty);
                    entries.Add(entry);
                    created.Add(inst);
                }
                else
                {
                    entry.Quantity += qty;
                    created.Add(entry.Instance);
                }
            }
            else
            {
                for(int i = 0; i < qty; i++)
                {
                    var inst = data.CreateInstance(1);
                    entries.Add(new InventoryEntry(inst, 1));
                    created.Add(inst);
                }
            }

            //EventBus<OnInventoryChanged>.Publish(this);
            Debug.Log("Innvoke OnInventoryChanged");
            return created;
        }

        /// <summary>
        /// Removes up to 'amount' of a given ItemID from inventory.
        /// Returns how many were removed.
        /// </summary>
        /// <param name="itemID"></param>
        /// <param name="qty"> quantity</param>
        /// <returns></returns>
        public int RemoveByItemID(string itemID, int qty = 1)
        {
            if (string.IsNullOrEmpty(itemID) || qty <= 0) return 0;
            if (!byItemID.TryGetValue(itemID, out var entries) || entries.Count == 0) return 0;

            int removed = 0;
            var data = entries[0].Instance.data;
            if (data == null) return 0;

            if (data.stackable)
            {
                var entry = entries[0];
                int toRemove = Math.Min(qty, entry.Quantity);
                entry.Quantity -= toRemove;
                removed += toRemove;
                if (entry.Quantity <= 0)
                    entries.Remove(entry);
            }
            else
            {
                // Remove severally from the end
                for (int i = entries.Count - 1; i >= 0 && removed < qty; --i)
                {
                    entries.RemoveAt(i);
                    removed++;
                }
            }

            if (entries.Count == 0)
                byItemID.Remove(itemID);

            if (removed > 0)
                //EventBus<OnInventoryChanged>.Publish(this);
                Debug.Log("Innvoke OnInventoryChanged");

            return removed;
        }

        /// <summary>
        /// Remove a specific runtime ItemInstance (useful for unique items).
        /// </summary>
        public bool RemoveInstance(ItemInstance inst)
        {
            if (inst == null) return false;
            string key = inst.ItemID;
            if (!byItemID.TryGetValue(key, out var entries)) return false;

            var found = entries.Find(e => e.Instance.InstanceID == inst.InstanceID);
            if (found == null) return false;

            if (inst.data.stackable)
            {
                // reduce the aggregated stack by 1 (or by found.Quantity if you want)
                found.Quantity = Math.Max(0, found.Quantity - 1);
                if (found.Quantity <= 0) entries.Remove(found);
            }
            else
            {
                entries.Remove(found);
            }

            if (entries.Count == 0) byItemID.Remove(key);

            //EventBus<OnInventoryChanged>.Publish(this);
            Debug.Log("Innvoke OnInventoryChanged");
            return true;
        }
        #endregion

        #region Presentable List / Query
        /// <summary>
        /// Presentable row used by UI: icon, name, quantity, reference to data & instances.
        /// </summary>
        public class PresentableRow
        {
            public string ItemID;
            public string Name;
            public Sprite Icon;
            public int Quantity;
            public ItemData Data;
            public ItemInstance RepresentativeInstance;// a reference to an instance (useful for equipping)
        }

        /// <summary>
        /// Returns a list of current items suitable for UI display.
        /// Note: this is a snapshot and safe to iterate.
        /// </summary>
        public List<PresentableRow> GetPresentableList()
        {
            var outList = new List<PresentableRow>();
            foreach (var kv in byItemID)
            {
                var entries = kv.Value;
                if (entries == null || entries.Count == 0) continue;

                var data = entries[0].Instance.data;
                if(data == null) continue;

                if(data.stackable)
                {
                    outList.Add(new PresentableRow
                    {
                        ItemID = data.itemID,
                        Name = data.itemName,
                        Icon = data.icon,
                        Quantity = entries[0].Quantity,
                        Data = data,
                        RepresentativeInstance = entries[0].Instance
                    });
                }
                else
                {
                    foreach (var e in entries)
                    {
                        outList.Add(new PresentableRow
                        {
                            ItemID = data.itemID,
                            Name = data.itemName,
                            Icon = data.icon,
                            Quantity = e.Quantity,
                            Data = data,
                            RepresentativeInstance = e.Instance
                        });
                    }
                }           
            }
            return outList;
        }

        /// <summary>
        /// Helper: returns current quantity of an item (0 if none).
        /// </summary>
        public int GetQuantity(string itemID)
        {
            if (string.IsNullOrEmpty(itemID)) return 0;
            if (!byItemID.TryGetValue(itemID, out var entries) || entries.Count == 0) return 0;
            var data = entries[0].Instance.data;
            if (data.stackable) return entries[0].Quantity;
            return entries.Count; // number of non-stackable instances
        }
        #endregion

        #region  Equip / Use helpers (integrate with EventBus)

        /// <summary>
        /// Use the specified item instance (calls the ItemData.Use method). If Use returns true,
        /// the inventory will remove one quantity automatically.
        /// </summary>
        public void UseItem(ItemInstance instance)
        {
            if (instance == null) return;
            bool consumed = instance.Use(this);
            if (consumed)
            {
                RemoveInstance(instance);
            }
        }

        /// <summary>
        /// Equip the representative instance of a presentable row:
        /// For equipment we publish EquipEvent so stat/equipment systems can react.
        /// The EquipmentSystem (or StatManagerEventBridge) will handle applying modifiers.
        /// </summary>
        public void EquipItem(ItemInstance instance)
        {
            if (instance == null || instance.data == null) return;
            if (!(instance.data is AniDrag.Interactibles.Equipment.EquipmentItemData equipmentData))
            {
                Debug.LogWarning($"Attempted to equip non-equippable item {instance.data.itemName}");
                return;
            }

            // Publish an EquipEvent with clones of the modifier prototypes (sourceID set to itemID).
            // We do not remove the item from inventory here - equipping behaviour (remove from bag / mark as equipped)
            // is up to your rules. Example below simply publishes the event.
            var equipMods = CloneModifiersForSource(equipmentData.itemID, equipmentData.modifierPrototypes);
            var ev = new AniDrag.Events.EquipEvent(equipmentData.itemID, equipMods);
            AniDrag.Events.EventBus<AniDrag.Events.EquipEvent>.Publish(ev);

            // If your game requires that equipping consumes the inventory slot (remove from bag),
            // call RemoveInstance(instance) here. Otherwise, track equipped items separately.
        }

        /// <summary>
        /// Unequip by itemID (publishes an UnequipEvent).
        /// </summary>
        public void UnequipByItemID(string itemID)
        {
            if (string.IsNullOrEmpty(itemID)) return;
            var ev = new AniDrag.Events.UnequipEvent(itemID);
            AniDrag.Events.EventBus<AniDrag.Events.UnequipEvent>.Publish(ev);
        }

        private AniDrag.Interactibles.Equipment.StatModifier[] CloneModifiersForSource(string sourceID, AniDrag.Interactibles.Equipment.StatModifier[] prototypes)
        {
            if (prototypes == null || prototypes.Length == 0) return Array.Empty<AniDrag.Interactibles.Equipment.StatModifier>();
            var outMods = new AniDrag.Interactibles.Equipment.StatModifier[prototypes.Length];
            for (int i = 0; i < prototypes.Length; ++i)
            {
                var p = prototypes[i];
                outMods[i] = new AniDrag.Interactibles.Equipment.StatModifier(sourceID, p.TargetStat, p.Operation, p.Value, p.Priority, p.Label);
            }
            return outMods;
        }


        #endregion

    }

    public class SortingEnums
    {
        public enum SortByType
        {
            All,
            Weapons,
            Armor,
            Consumable,
            Material,
            KeyItems,
        }

        public enum SortByAtribute
        {
            All,
            Damage,
            Health,
            Defense,
        }

        public enum SortFilter
        {
            Name,
            Quantity,
        }
    }
}
