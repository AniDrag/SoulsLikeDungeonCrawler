﻿using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

    
namespace AniDrag.Stats
{
    /// <summary>
    /// Since stats will be made with presets of characters. with a 10SP limit we will be able to create our character.
    /// Oters will use A preset for certian group of enemy type.
    /// </summary>
    [System.Serializable]
    public class StatDefinition
    {
        public string StatName;
        public StatsType Type { get; }
        public float BaseValue { get; private set; }

        // Active modifiers from BuffInstances: tracked as lists for quick calc
        private readonly List<float> flatModifiers = new List<float>();
        private readonly List<float> percentModifiers = new List<float>(); // e.g. 0.1f = +10%

        public float FinalValue { get; private set; }

        public StatDefinition(StatsType type, float baseValue = 0f)
        {
            Type = type;
            BaseValue = baseValue;
            Recalculate();
        }
        #region Functions
        public void SetBase(float v) { BaseValue = v; Recalculate(); }
        public void AddFlat(float f) { flatModifiers.Add(f); Recalculate(); }
        public void RemoveFlat(float f) { flatModifiers.Remove(f); Recalculate(); }

        public void AddPercent(float p) { percentModifiers.Add(p); Recalculate(); }
        public void RemovePercent(float p) { percentModifiers.Remove(p); Recalculate(); }

        public void Recalculate()
        {
            // heavy calculations here, but kept simple
            float flatTotal = 0f;
            for (int i = 0; i < flatModifiers.Count; i++) flatTotal += flatModifiers[i];

            float multTotal = 1f;
            for (int i = 0; i < percentModifiers.Count; i++)
                multTotal *= (1f + percentModifiers[i]); // multiplicative stacking

            FinalValue = (BaseValue + flatTotal) * multTotal;
        }
        #endregion

    }
   //public enum StatType
   //{
   //    Unnset,
   //    //Default stats
   //    VIT,
   //    STA,
   //    MAG,
   //    STR,
   //    DEX,
   //    INT,
   //    LUC,
   //
   //    //Substats
   //    Health,
   //    Stamina,
   //    Mana,
   //    PhysicalDamage,
   //    MagicDamage,
   //    PhysicalDefense,
   //    MagicalDefense,
   //    CritDamage,
   //    CritChance,
   //    LootDiscovery,
   //}
}