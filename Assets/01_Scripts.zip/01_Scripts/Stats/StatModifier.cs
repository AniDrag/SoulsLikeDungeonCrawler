// =============================================================
// File: StatModifier.cs
// Purpose: Defines StatModifier and supporting enums used to change
//          base stats (flat, percent, multiplier). Designed to be
//          lightweight and serializable so you can create modifiers
//          at runtime and remove them by source ID.
// =============================================================

using System;
using UnityEngine;
namespace AniDrag.Interactibles.Equipment
{
    /// <summary>
    /// What kind of modification this modifier applies to a stat.
    /// </summary>
    public enum ModifierOperation
    {
        /// <summary>Simple additive flat value (e.g. +5 HP)</summary>
        Flat,


        /// <summary>Percent additive: expressed as fraction when used (e.g. 0.15f = +15%)
        /// Provided API accepts percents as whole numbers (15 => 15%) for convenience.
        /// Final calculation sums percent modifiers and applies them as (1 + sumPercent).
        /// </summary>
        Percent,


        /// <summary>Multiplicative factor. Values are applied multiplicatively after percent.
        /// Example: 1.1f = +10% multiplier, 0.9f = -10% multiplier. Multipliers multiply together.
        /// </summary>
        Multiplier
    }

    /// <summary>
    /// Serializable runtime modifier that targets a single StatType.
    /// Use SourceID to identify the origin (e.g. equipment ID, buff ID) so we can remove all
    /// modifiers that come from the same source in one call.
    /// Example usage is SwordOfDestiny ID
    ///                     Has a List<StatModifiers> itemModifiers.
    ///                     and pplies all of them to player.
    /// </summary>
    [Serializable]
    public class StatModifier
    {
        /// <summary>
        /// Unique identifier representing the source of this modifier.
        /// Examples: an equipment item's GUID, a buff instance ID, "ITEM_SWORD_001".
        /// Removing modifiers by SourceID is how you detach equipment buffs, etc.
        /// </summary>
        public string SourceID;

        /// <summary>Which stat this modifier affects.</summary>
        public StatsType TargetStat;

        /// <summary>Operation type (Flat, Percent, Multiplier).</summary>
        public ModifierOperation Operation;

        /// <summary>
        /// The numeric value of the modifier.
        /// - For Flat: stored as the raw additive value (e.g. +5).
        /// - For Percent: stored as fraction (0.15f = +15%).
        ///   When creating modifiers via constructors you can pass percent as whole numbers
        ///   and the helper will convert (15 -> 0.15f).
        /// - For Multiplier: stored as multiplicative factor (1.1f = +10%).
        /// </summary>
        public float Value;

        /// <summary>
        /// Optional priority for ordering. Higher priority modifiers are applied first in
        /// deterministic ordering. Defaults to 0.
        /// </summary>
        public int Priority;

        /// <summary>
        /// Human-friendly name for debugging/inspector.
        /// </summary>
        public string Label;

        /// <summary>
        /// Constructor for a raw modifier (Value is used directly).
        /// </summary>
        public StatModifier(string sourceID, StatsType target, ModifierOperation op, float value, int priority = 0, string label = null)
        {
            SourceID = sourceID;
            TargetStat = target;
            Operation = op;
            Value = value;
            Priority = priority;
            Label = label ?? $"{op}: {value}";
        }

        /// <summary>
        /// Convenience constructor for percent expressed as a whole number (e.g. 15 -> 15%).
        /// Use this when you prefer working with percent integers.
        /// </summary>
        public static StatModifier Percent(string sourceID, StatsType target, float percentWholeNumber, int priority = 0, string label = null)
        {
            return new StatModifier(sourceID, target, ModifierOperation.Percent, percentWholeNumber / 100f, priority, label ?? $"%{percentWholeNumber}");
        }

        /// <summary>
        /// Convenience constructor for multiplier expressed as a factor (e.g. 1.1f = +10%).
        /// </summary>
        public static StatModifier Mult(string sourceID, StatsType target, float multiplierFactor, int priority = 0, string label = null)
        {
            return new StatModifier(sourceID, target, ModifierOperation.Multiplier, multiplierFactor, priority, label ?? $"x{multiplierFactor}");
        }

        /// <summary>
        /// Convenience constructor for a flat modifier.
        /// </summary>
        public static StatModifier Flat(string sourceID, StatsType target, float flatAmount, int priority = 0, string label = null)
        {
            return new StatModifier(sourceID, target, ModifierOperation.Flat, flatAmount, priority, label ?? $"+{flatAmount}");
        }
    }




    // =============================================================
    // File: ExampleUsage.cs
    // Purpose: Demonstrates how to wire StatManager in a simple MonoBehaviour
    //          and how to add/remove modifiers from equipment and buffs.
    // =============================================================


    public class ExampleUsage : MonoBehaviour
    {
        [Tooltip("Reference to the StatManager on the character (can be same object)")]
        public StatManager statManager;

        private string swordSourceID = "EQUIP_SWORD_001";
        private StatModifier swordDamageMod;

        private void Start()
        {
            if (statManager == null) statManager = GetComponent<StatManager>();

            // Example: Add a new flat damage from a sword when equipping
            swordDamageMod = statManager.AddFlatModifier(swordSourceID, StatsType.PhysicalDamage, 8, priority: 10, label: "Sword +8 DMG");

            // Example: Add a percent buff (e.g. temporary buff +20% HP)
            statManager.AddPercentModifier("BUFF_HEALTH_001", StatsType.Health, 20f, label: "Health Blessing");

            // Example: Add a multiplicative buff (e.g. global damage multiplier from skill)
            statManager.AddMultiplierModifier("SKILL_FURY", StatsType.PhysicalDamage, 1.15f, label: "Fury x1.15");

            // Read a final value
            int finalDamage = statManager.GetFinalInt(StatsType.PhysicalDamage);
            Debug.Log($"Final Physical Damage: {finalDamage}");
        }

        private void OnDisable()
        {
            // When unequipping the sword remove all modifiers from that source
            statManager.RemoveModifiersBySource(swordSourceID);
        }
    }
}