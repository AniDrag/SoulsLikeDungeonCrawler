// =============================================================
// File: StatManager.cs
// Purpose: Aggregates base StatCore entries with runtime StatModifier instances
//          (equipment, buffs, skills) and exposes final values and utilities
//          for adding / removing modifiers by source. Also exposes events for UI
//          updates and a presentable stats list.
// =============================================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
namespace AniDrag.Interactibles.Equipment
{
    /// <summary>
    /// Unity component that manages character stats. Use the inspector to populate
    /// the base stats (StatCore) for your character class. At runtime add / remove
    /// StatModifier objects to apply equipment and buff effects.
    ///
    /// Calculation order (deterministic):
    ///  1) Sum all Flat modifiers for the stat -> sumFlat
    ///  2) Calculate (BaseValue + sumFlat)
    ///  3) Multiply by BaseMultiplier
    ///  4) Sum all Percent modifiers (these are additive percent fractions) -> sumPercent
    ///     Apply as (1 + sumPercent)
    ///  5) Multiply by product of all Multipliers (e.g. 1.1 * 0.9 * ...)
    ///
    /// Final formula: final = ((BaseValue + sumFlat) * BaseMultiplier) * (1 + sumPercent) * productMultipliers
    ///
    /// The manager keeps all active modifiers in a list and allows removal by SourceID
    /// (useful when unequipping items or clearing buffs).
    /// </summary>
    public class StatManager : MonoBehaviour
    {
        [Header("Base stat setup")]
        [Tooltip("Populate this list with your character's base stats. Each StatCore is one stat.")]
        [SerializeField]
        private List<StatCore> baseStatsList = new List<StatCore>();

        // Internal lookup for quick access during runtime
        private Dictionary<StatsType, StatCore> baseStats = new Dictionary<StatsType, StatCore>();

        [Header("Runtime modifiers")]
        [Tooltip("Active stat modifiers (equipment, buffs, abilities). Modify at runtime via AddModifier/RemoveBySource.")]
        [SerializeField]
        private List<StatModifier> activeModifiers = new List<StatModifier>();

        // Event fired when any stat changes. Provides the affected StatType.
        public UnityEvent<StatsType> OnStatChanged = new UnityEvent<StatsType>();

        // Event fired after a full refresh (useful for UI to rebuild entire stat list)
        public UnityEvent OnStatsRefreshed = new UnityEvent();

        private void Awake()
        {
            RebuildLookup();
            // Initial calculation so inspector shows values in editor/play mode
            RecalculateAll();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            // keep the lookup in sync for editor-time changes
            RebuildLookup();
            RecalculateAll();
        }
#endif

        /// <summary>
        /// Rebuilds the internal dictionary from the inspector list. This is called
        /// automatically on Awake and OnValidate. Call it if you reconfigure baseStatsList at runtime.
        /// </summary>
        public void RebuildLookup()
        {
            baseStats.Clear();
            foreach (var core in baseStatsList)
            {
                if (core == null) continue;
                baseStats[core.StatType] = core;
            }
        }

        /// <summary>
        /// Adds a modifier to the active list and recalculates the affected stat.
        /// </summary>
        /// <param name="mod">Modifier to add (must have a valid TargetStat).</param>
        public void AddModifier(StatModifier mod)
        {
            if (mod == null) return;
            activeModifiers.Add(mod);
            // Keep deterministic order by priority (higher priority first)
            activeModifiers = activeModifiers.OrderByDescending(m => m.Priority).ToList();
            RecalculateStat(mod.TargetStat);
        }

        /// <summary>
        /// Removes a single modifier instance (reference-equality). Returns true if removed.
        /// </summary>
        public bool RemoveModifier(StatModifier mod)
        {
            if (mod == null) return false;
            bool removed = activeModifiers.Remove(mod);
            if (removed)
                RecalculateStat(mod.TargetStat);
            return removed;
        }

        /// <summary>
        /// Removes all modifiers with the provided SourceID. Useful when unequipping an item
        /// or cancelling a buff that added multiple modifiers.
        /// Returns the number removed.
        /// </summary>
        public int RemoveModifiersBySource(string sourceID)
        {
            if (string.IsNullOrEmpty(sourceID)) return 0;
            int before = activeModifiers.Count;
            var toRemove = activeModifiers.Where(m => m.SourceID == sourceID).ToList();
            foreach (var r in toRemove) activeModifiers.Remove(r);
            int removedCount = before - activeModifiers.Count;
            if (removedCount > 0)
            {
                // Recalculate every affected stat for safety (small number of stats -> cheap)
                var affectedStats = toRemove.Select(m => m.TargetStat).Distinct();
                foreach (var s in affectedStats) RecalculateStat(s);
            }
            return removedCount;
        }

        /// <summary>
        /// Clears all runtime modifiers. Useful for debugging or a full reset.
        /// </summary>
        public void ClearAllModifiers()
        {
            activeModifiers.Clear();
            RecalculateAll();
        }

        /// <summary>
        /// Returns the list of active modifiers (read-only copy).
        /// </summary>
        public IReadOnlyList<StatModifier> GetActiveModifiers() => activeModifiers.AsReadOnly();

        /// <summary>
        /// Recalculates a single stat, updates inspector value in the StatCore and fires OnStatChanged.
        /// </summary>
        public void RecalculateStat(StatsType stat)
        {
            if (!baseStats.TryGetValue(stat, out var core))
                return; // stat not present

            // Collect relevant modifiers
            var mods = activeModifiers.Where(m => m.TargetStat == stat).ToList();

            // Sum flat modifiers
            float sumFlat = mods.Where(m => m.Operation == ModifierOperation.Flat).Sum(m => m.Value);

            // Sum percent modifiers (values are stored as fractions, e.g. 0.15f = 15%)
            float sumPercent = mods.Where(m => m.Operation == ModifierOperation.Percent).Sum(m => m.Value);

            // Product of multipliers
            float productMult = mods.Where(m => m.Operation == ModifierOperation.Multiplier).Aggregate(1f, (acc, m) => acc * m.Value);

            float computed = ((core.BaseValue + sumFlat) * core.BaseMultiplier) * (1f + sumPercent) * productMult;

            // Update inspector field for debugging
            core.SetInspectorFinal(computed);

            OnStatChanged?.Invoke(stat);
        }

        /// <summary>
        /// Recalculates all stats and fires a global refresh event.
        /// </summary>
        public void RecalculateAll()
        {
            foreach (var kv in baseStats)
                RecalculateStat(kv.Key);
            OnStatsRefreshed?.Invoke();
        }

        /// <summary>
        /// Returns the final float value for a stat (before rounding) or null if stat doesn't exist.
        /// </summary>
        public float? GetFinalFloat(StatsType stat)
        {
            if (!baseStats.TryGetValue(stat, out var core)) return null;

            var mods = activeModifiers.Where(m => m.TargetStat == stat).ToList();
            float sumFlat = mods.Where(m => m.Operation == ModifierOperation.Flat).Sum(m => m.Value);
            float sumPercent = mods.Where(m => m.Operation == ModifierOperation.Percent).Sum(m => m.Value);
            float productMult = mods.Where(m => m.Operation == ModifierOperation.Multiplier).Aggregate(1f, (acc, m) => acc * m.Value);

            float computed = ((core.BaseValue + sumFlat) * core.BaseMultiplier) * (1f + sumPercent) * productMult;
            return computed;
        }

        /// <summary>
        /// Returns the final rounded integer value for a stat (0 if not present).
        /// </summary>
        public int GetFinalInt(StatsType stat)
        {
            float? f = GetFinalFloat(stat);
            if (!f.HasValue) return 0;
            return Mathf.RoundToInt(f.Value);
        }

        /// <summary>
        /// Helper: Adds a flat modifier and returns the modifier instance (so you can remove it individually).
        /// Example: var m = statManager.AddFlatModifier("SWORD_ID", StatType.Health, 10);
        /// Later: statManager.RemoveModifier(m);
        /// </summary>
        public StatModifier AddFlatModifier(string sourceID, StatsType stat, float amount, int priority = 0, string label = null)
        {
            var m = StatModifier.Flat(sourceID, stat, amount, priority, label);
            AddModifier(m);
            return m;
        }

        /// <summary>
        /// Helper: Adds a percent modifier by passing a whole-number percent (e.g. 15 => +15%).
        /// Returns the created modifier instance.
        /// </summary>
        public StatModifier AddPercentModifier(string sourceID, StatsType stat, float percentWholeNumber, int priority = 0, string label = null)
        {
            var m = StatModifier.Percent(sourceID, stat, percentWholeNumber, priority, label);
            AddModifier(m);
            return m;
        }

        /// <summary>
        /// Helper: Adds a multiplicative modifier (factor) and returns it.
        /// Example: AddMultiplier("BUFF_ID", StatType.Damage, 1.2f) -> +20% multiplicative.
        /// </summary>
        public StatModifier AddMultiplierModifier(string sourceID, StatsType stat, float multiplierFactor, int priority = 0, string label = null)
        {
            var m = StatModifier.Mult(sourceID, stat, multiplierFactor, priority, label);
            AddModifier(m);
            return m;
        }

        /// <summary>
        /// Returns a presentable snapshot of all stats and their final rounded values.
        /// Useful for UI lists. The returned list is new and safe to iterate.
        /// </summary>
        public List<(StatsType stat, int value)> GetPresentableStats()
        {
            var list = new List<(StatsType stat, int value)>();
            foreach (var kv in baseStats)
            {
                list.Add((kv.Key, GetFinalInt(kv.Key)));
            }
            return list;
        }
    }
}