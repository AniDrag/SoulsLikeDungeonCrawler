// =============================================================
// File: StatCore.cs
// Purpose: Simple serializable container that holds a stat's base values.
//          It contains no runtime modifiers. The StatManager aggregates StatCore
//          with StatModifier instances to produce final values.
// =============================================================
using System;

using UnityEngine;

/// <summary>
/// Serializable base stat values. Keep this lightweight and focused on the canonical
/// "base" numbers provided by the character's class / level / default equipment.
///</summary>
[Serializable]
public class StatCore
{
    [Header("Identity")]
    [Tooltip("Which stat this core represents (used by the StatManager mapping)")]
    public StatsType StatType;

    [Header("Base values")]
    [Tooltip("Primary base value. Integer for most stats (HP, Damage), but you may switch to float if needed.")]
    public float BaseValue = 1f;
    [Tooltip("A base multiplier applied to the stat before external modifiers. Example: 1.0 = no change.")]
    public float BaseMultiplier = 1f;

    [Header("Inspector (read-only) ")]
    [Tooltip("Computed final value after aggregation. Serialized for debugging and inspection only.")]
    [SerializeField] private float inspectorFinalValue = 1f;

    /// <summary>
    /// Helper used by the StatManager to show the computed value in the inspector.
    /// StatManager will set this during calculation; you generally should not set it manually.
    /// </summary>
    public void SetInspectorFinal(float val)
    {
        inspectorFinalValue = val;
    }

    /// <summary>
    /// Shallow copy utility used by the manager when it needs an isolated copy.
    /// </summary>
    public StatCore Clone()
    {
        return new StatCore
        {
            StatType = this.StatType,
            BaseValue = this.BaseValue,
            BaseMultiplier = this.BaseMultiplier,
            inspectorFinalValue = this.inspectorFinalValue
        };
    }
}


