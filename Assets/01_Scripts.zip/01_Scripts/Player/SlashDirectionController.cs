using UnityEngine;
using UnityEngine.InputSystem;

public class SlashDirectionController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform slashIndicator;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private float rotationSpeed = 720f;

    private Vector2 aimInput;
    private string lastInputType = "Mouse"; // or "Gamepad"
    private bool usingController => lastInputType == "Gamepad";

    public void OnAim(InputAction.CallbackContext ctx)
    {
        aimInput = ctx.ReadValue<Vector2>();

        // Detect input source type
        if (ctx.control.device is Gamepad)
            lastInputType = "Gamepad";
        else if (ctx.control.device is Mouse)
            lastInputType = "Mouse";
    }

    void Update()
    {
        if (slashIndicator == null || mainCamera == null) return;

        Vector3 targetDir = Vector3.zero;

        if (usingController)
        {
            // Ignore tiny stick noise
            if (aimInput.sqrMagnitude < 0.01f) return;

            targetDir = new Vector3(aimInput.x, aimInput.y, 0f);
        }
        else // using mouse
        {
            Vector3 mouseWorld = mainCamera.ScreenToWorldPoint(aimInput);
            mouseWorld.z = 0;

            targetDir = mouseWorld - slashIndicator.position;
        }

        float targetAngle = Mathf.Atan2(targetDir.y, targetDir.x) * Mathf.Rad2Deg;
        Quaternion targetRotation = Quaternion.Euler(0, 0, targetAngle);

        slashIndicator.rotation = Quaternion.RotateTowards(
            slashIndicator.rotation,
            targetRotation,
            rotationSpeed * Time.deltaTime
        );
    }
    void OnDrawGizmos()
    {
        if (slashIndicator != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawLine(slashIndicator.position,
                slashIndicator.position + slashIndicator.right * 2f);
        }
    }
}
