[System.Serializable]
public class DamageData 
{
    public int damage = 10;
    public int physicalDefenseIgnore = 0;
    public int magicDefenseIgnore = 0;
    public DamageType damageType = DamageType.Physical;
    public ElementType elementType = ElementType.None;
    public StatusType statusType = StatusType.None;
    public float critMultiplier = 1f;
    public int critchance = 5;
    public bool IsCritical => critMultiplier > 1f;

    public DamageData(int damage = 1, DamageType damageType = DamageType.Physical, ElementType elementType = ElementType.None, StatusType statusType = StatusType.None, float critMultiplier = 1f, int critchance = 5)
    {
        this.damage = damage;
        this.damageType = damageType;
        this.elementType = elementType;
        this.statusType = statusType;
        this.critMultiplier = critMultiplier;
        this.critchance = critchance;
    }


}
/// <summary>
/// True damage ignores defense
/// </summary>
public enum DamageType
{
    Physical,
    Magical,
    Status,
}
public enum ElementType
{
    None,
    Fire,
    BlackFlame,
    Ice,
    Water,
    Earth,
    Lightning,
    Holy,
    Dark,
    Spirit,
}
public enum StatusType
{
    None,
    Poison,
    Corosion,
    Heat,
    Cold,
    Radiation,
    Bleading,
}

