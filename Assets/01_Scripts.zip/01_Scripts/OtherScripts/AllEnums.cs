using System;
public enum StatsType
{
    //Other stat types
    Absorption,// absorbs damage

    // player base stats
    Health,
    Magic, // magic amount
    Stamina,// stamina amount
    Speed, // player moveent speed
    Strength, // physical strenght. Increase damage on weapon types.
    Dexterity, // dexterity and speed of weapon attacks. Increase damage on weapon types.
    Intelligence, // Magic attack, and cast speed. Increase damage on ewapon types.
    Charisma, // Shop prices and quest rewards.
    Sense, // how good your hearing is. At a certian level hilights mobs on map and tghru walls.
    Luck, // Luck in all things. Status resist, Crit chance, Loot finds, drops of mobs...

    //Armor Stats
    CritResistance, // resists critical strikes
    PhysicalDefense, // Physical damage negation
    MagicDefense, // Magical damage negation
    FireDefense, // Fire damage negation, reduces heat build up.
    ColdDefense, // Cold damage negation, reduces cold buildup.
    PenetrationResistance, // durability damage reduction, and how much penetration is applied to damage effect.
    Durability, // equipment durability

    //Weapon Stats
    PhysicalDamage, // physical damage applied
    MagicDamage, // magical damage applied
    FireDamage, // Fire damage, --> status Heat applied
    ColdDamage, // Cold Damage, --> status cold applied. Deals damage if cold reaches 100%
    PenetrationPercent, // Decrese final Physical defense stat by percent. 100% means no physical damage reduction is applied.
    DurabilityDamage,// how much durability damage is caused to equipment.
    AttackRate,// speed of attack
    CritChance, // chance of a critical strike.
    CritDamage,// Multiplayer on final damage output.

    // Ailments
    Cold, // cold build up to 100% deals % damage and damage buildup to player once filled.
    Heat, // Heat buildup. Reduces Armor by 50% at max value, reduces MP regen yb 10% at max value. 10% health damage on full effect. smart to keep it at 90% so u can enjoi previous effects.
    Bleed,// deals 30% damage when at max value.
    Poison,// deals .2% damage for 60s
    Corrosion, // Strips armor value by 60% and high durability damage on Armor.


}

[Serializable]
public enum ModifierType { Flat, PercentAdd, PercentMult }
public enum Polarity
{
    None,
    Fire,
    Water,
    Earth,
    Dark,
    Light
}
public enum CharacterClass
{
    None,
    Strenght,
    Dexterity,
    Agility,
    Fortitude,
    Arcane,
    Faith,
    Magic,
    Luck,
}
