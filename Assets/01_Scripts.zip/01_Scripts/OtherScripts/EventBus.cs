namespace AniDrag.Events
{
    using AniDrag.Player;
    using AniDrag.Interactibles.Equipment;
    using System;

    //// <summary>
    /// Minimal base type required by EventBus generic constraint.
    /// Keep this empty or add common metadata (timestamp) if you like.
    /// </summary>
    public abstract class Event { }

    /// <summary>
    /// Generic static event bus. Each T has its own static event list.
    /// Usage: EventBus{EquipEvent}.OnEvent += Handler; EventBus{EquipEvent}.Publish(ev);
    /// </summary>
    /// <typeparam name="T">Event type deriving from Event</typeparam>
    public static class EventBus<T> where T : Event
    {
        /// <summary>
        /// Public static event. Subscribe with += and remember to unsubscribe with -=.
        /// </summary>
        public static event Action<T> OnEvent;

        /// <summary>
        /// Publish an event instance to all subscribers of T.
        /// Uses null-conditional invoke so it's safe when there are no listeners.
        /// </summary>
        public static void Publish(T ev) => OnEvent?.Invoke(ev);
    }


    /// <summary>
    /// An event to notify all subscribers that care about money
    /// </summary>
    public class GetMoneyEvent : Event
    {
        public readonly int money;
        //It's rare to see a constructor!
        public GetMoneyEvent(int pMoney)
        {
            money = pMoney;
        }
    }

    /// <summary>
    /// A on kill event. Is trigered on enemy death. gets gameobject name from damage source and checks quests linked to said target.
    /// Supports multiplayer/ Co op. and keeps it clean if player doesnt kill the monster or if the monsters fight eachother this will
    /// resolve issues of random kill increase or random rewards.
    /// </summary>
    public class EnemyKill : Event
    {
        public enum EnemyType
        {
            Skeleton,
            Zombie,
            Slime,
            Boss
        }
        public ElementType type;

        public EnemyKill(ElementType ptype)
        {
            type = ptype;
        }
    }

    /// <summary>
    /// Event fired when something is equipped. Contains the source ID (usually the item's stable GUID)
    /// and the modifiers that should be applied. StatManager listens for this and adds the modifiers.
    /// </summary>
    public class EquipEvent : Event
    {
        public readonly string SourceID;
        public readonly StatModifier[] Modifiers;

        public EquipEvent(string sourceID, StatModifier[] modifiers)
        {
            SourceID = sourceID;
            Modifiers = modifiers ?? Array.Empty<StatModifier>();
        }
    }

    /// <summary>
    /// Event fired when something is unequipped. Listeners should remove modifiers by SourceID.
    /// </summary>
    public class UnequipEvent : Event
    {
        public readonly string SourceID;

        public UnequipEvent(string sourceID)
        {
            SourceID = sourceID;
        }
    }

    /// <summary>
    /// Event fired whenever inventory changes. Subscribe your UI to this.
    /// </summary>
    public class OnInventoryChanged : Event
    {
        public Inventory inventory;

        public OnInventoryChanged(Inventory pInventory) { inventory = pInventory; }
    }
}