using UnityEngine;

public interface IInteract
{
     void InteractWithItem()
    {
        Debug.Log("Interacted");
    }
}
public interface IDamageable
{
    void TakeDamage(DamageData data);
}
