using UnityEngine;
using System.Collections.Generic;

namespace AniDrag.Stats
{

    public class StatModifierDefinition : MonoBehaviour
    {
        public string buffID = "unsett";
        public BuffType type;
        public bool isNegative = false;
        [SerializeField] List<StatDefinition> atributeModifiers = new List<StatDefinition>();// all stat buffs/Debuffs
        public StatModifierDefinition(string id, BuffType type, bool isNegative, List<StatDefinition> statModifiers)
        {
            buffID = id;
            this.type = type;
            this.isNegative = isNegative;
            atributeModifiers = statModifiers;
        }
    }

   
    
    public enum BuffType
    {
        Duration,
        Equipment,
        Ratial,
        Class,
        SubClass,
        Permenant,
        World,
    }
}
